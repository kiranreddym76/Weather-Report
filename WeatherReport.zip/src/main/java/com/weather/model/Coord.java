package com.weather.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Coord implements Serializable{
	
	private static final long serialVersionUID = 7156526077883281630L;
	
	 @JsonProperty("lon")
	 private double lon;
	 
	 @JsonProperty("lat")
	 private double lat;

	public double getLon() {
		return lon;
	}

	public void setLon(double lon) {
		this.lon = lon;
	}

	public double getLat() {
		return lat;
	}

	public void setLat(double lat) {
		this.lat = lat;
	}

}
