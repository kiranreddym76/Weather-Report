package com.weather.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Main implements Serializable{
	
	private static final long serialVersionUID = 7156526077883281626L;
	
	@JsonProperty("temp")
	private double temperature;
	
	@JsonProperty("feels_like")
	private double feelsLike;
	
	@JsonProperty("temp_min")
	private double tempMin;
	
	@JsonProperty("temp_max")
	private double tempMax;
	
	@JsonProperty("pressure")
	private int pressure;
	
	@JsonProperty("humidity")
	private int humidity;
	
	@JsonProperty("sea_level")
	private int seaLevel;
	
	@JsonProperty("grnd_level")
	private int grndLevel;

	public double getTemperature() {
		return temperature;
	}

	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}

	public double getFeelsLike() {
		return feelsLike;
	}

	public void setFeelsLike(double feelsLike) {
		this.feelsLike = feelsLike;
	}

	public double getTempMin() {
		return tempMin;
	}

	public void setTempMin(double tempMin) {
		this.tempMin = tempMin;
	}

	public double getTempMax() {
		return tempMax;
	}

	public void setTempMax(double tempMax) {
		this.tempMax = tempMax;
	}

	public int getPressure() {
		return pressure;
	}

	public void setPressure(int pressure) {
		this.pressure = pressure;
	}

	public int getHumidity() {
		return humidity;
	}

	public void setHumidity(int humidity) {
		this.humidity = humidity;
	}

	public int getSeaLevel() {
		return seaLevel;
	}

	public void setSeaLevel(int seaLevel) {
		this.seaLevel = seaLevel;
	}

	public int getGrndLevel() {
		return grndLevel;
	}

	public void setGrndLevel(int grndLevel) {
		this.grndLevel = grndLevel;
	}

}
