package com.weather.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Weather implements Serializable{
	
	private static final long serialVersionUID = 7156526077883281627L;

	@JsonProperty("id")
	private int id;
	
	@JsonProperty("main")
	private String main;
	
	@JsonProperty("description")
	private String description;
	
	@JsonProperty("icon")
	private String icon;

	public long getId() {
		return id;
	}

	public String getMain() {
		return main;
	}

	public void setMain(String main) {
		this.main = main;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public void setId(int id) {
		this.id = id;
	}

}
