package com.weather.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Wind implements Serializable{
	
	private static final long serialVersionUID = 7156526077883281628L;

	@JsonProperty("speed")
    private double speed;
	
	@JsonProperty("deg")
	private int deg;
	
	@JsonProperty("gust")
	private double gust;

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public int getDeg() {
		return deg;
	}

	public void setDeg(int deg) {
		this.deg = deg;
	}

	public double getGust() {
		return gust;
	}

	public void setGust(double gust) {
		this.gust = gust;
	}
}
