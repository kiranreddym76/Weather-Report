package com.weather.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Clouds implements Serializable{
	
	private static final long serialVersionUID = 7156526077883281631L;
	
	@JsonProperty("all")
	private long all;

	public long getAll() {
		return all;
	}

	public void setAll(long all) {
		this.all = all;
	}
}
