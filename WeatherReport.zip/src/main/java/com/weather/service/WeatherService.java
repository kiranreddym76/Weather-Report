package com.weather.service;

import com.weather.model.WeatherReport;

public interface WeatherService {

	 WeatherReport getWeather(String location);
}
